//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ArdOscil.rc
//
#define IDD_ARDOSCIL_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_ACCELERATOR1                129
#define IDC_SCOPE                       1000
#define IDC_PLOT_BUTTON                 1001
#define IDC_CLEAR_BUTTON                1002
#define IDC_START_BUTTON1               1003
#define IDC_STOP_BUTTON2                1004
#define IDC_RESULT                      1005
#define IDC_EDIT3                       1007
#define IDC_CT                          1007
#define IDC_NUMBER                      1008
#define IDC_BUTTON1                     1009
#define IDC_BUTTON2                     1010
#define IDC_NUMBER2                     1011
#define IDC_CLEAR                       1011
#define IDC_BUTTON3                     1012
#define IDC_SAVE                        1012
#define IDC_EDIT1                       1013
#define IDC_DIV                         1014
#define IDC_COMBO1                      1015
#define IDC_BEGIN                       1017
#define IDC_END                         1018
#define IDC_CALC                        1019
#define IDC_CLR                         1020
#define IDEXIT                          1021
#define IDC_COMBO2                      1022
#define ID_ACCELERATOR32774             32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
